#include <iostream>
#include <string>
using namespace std;

int main()
{
	const int BASIC_CHARGE = 40;
	const double EXTRA_TEXT_MESSAGE_CHARGE = 0.11;
	int minutesUsed;
	int textMessages;
	string customerName;
	int monthNumber;
	double amount;
	
	cout.setf(ios::fixed);			// Allows for the cost to be represented in dollars and cents
	cout.precision(2);

	cout << "Minutes used: ";
	cin >> minutesUsed;
	if (minutesUsed < 0)			// Checks for incorrect input of negative minutes
	{
		cout << "---" << endl;
		cout << "The number of minutes used must be nonnegative." << endl;
		return 1;
	}
	cout << "Text messages: ";
	cin >> textMessages; 
	if (textMessages < 0)			// Checks for incorrect input of negative text messages
	{
		cout << "---" << endl;
		cout << "The number of text messages must be nonnegative." << endl;
		return 1;
	}
	cout << "Customer name: ";
	cin.ignore(10000, '\n');		// Used to ignore the new line input from previous cin for int
	getline(cin, customerName);
	if (customerName == "")			// Checks for incorrect input of empty string for name
	{
		cout << "---" << endl;
		cout << "You must enter a customer name." << endl;
		return 1;
	}
	cout << "Month number (1=Jan, 2=Feb, etc.): ";
	cin >> monthNumber;
	if (monthNumber < 1 || monthNumber > 12)	// Checks for incorrect input of month int
	{
		cout << "---" << endl;
		cout << "The month number must be in the range 1 through 12." << endl;
		return 1;
	}
	cout << "---" << endl;
	int notFreeMinutes;
	double minuteCost = 0;
	if (minutesUsed > 500)		// Calculates the cost of minutes used after 500 minutes
	{
		notFreeMinutes = minutesUsed - 500;
		minuteCost = notFreeMinutes * 0.45;
	}
	int notFreeText = 0;
	int extraText = 0;
	if (textMessages > 200)		// Calcualtes the amount of text messages that cost money
	{
		notFreeText = textMessages - 200;
		if (notFreeText > 200)	// Calculates the amount of text messages that are beyond the 400th
		{
			extraText = notFreeText - 200;
		}
	}
	double textMessageCost;
	int numberTextAtNormalPrice = notFreeText - extraText;
	if (monthNumber >= 6 && monthNumber <= 9)	// Factors price depending on summer discount
	{
		textMessageCost = numberTextAtNormalPrice * 0.02;
	}
	else
	{
		textMessageCost = numberTextAtNormalPrice * 0.03;
	}

	amount = BASIC_CHARGE + minuteCost + textMessageCost + (extraText * EXTRA_TEXT_MESSAGE_CHARGE);
	cout << "The bill for " << customerName << " is $" << amount << endl;
}
